"""
Modulo: Album
Representa el TDA individual definido en el diagrama UML del TP0.
"""


class Album:
    """
    Representa un album musical individual.

    Atributos privados (encapsulados):
        _titulo (str)
        _artista (str)
        _genero (str)
        _anio (int)
    """

    def __init__(self, titulo: str, artista: str, genero: str, anio: int):
        self._titulo = titulo
        self._artista = artista
        self._genero = genero
        self._anio = anio

    # ---------- Getters (encapsulamiento) ----------
    @property
    def titulo(self) -> str:
        return self._titulo

    @property
    def artista(self) -> str:
        return self._artista

    @property
    def genero(self) -> str:
        return self._genero

    @property
    def anio(self) -> int:
        return self._anio

    # ---------- Serializacion para persistencia en JSON ----------
    def to_dict(self) -> dict:
        return {
            "titulo": self._titulo,
            "artista": self._artista,
            "genero": self._genero,
            "anio": self._anio,
        }

    @staticmethod
    def from_dict(data: dict) -> "Album":
        return Album(
            titulo=data["titulo"],
            artista=data["artista"],
            genero=data["genero"],
            anio=data["anio"],
        )

    def __str__(self) -> str:
        return f"'{self._titulo}' - {self._artista} ({self._anio}) [{self._genero}]"

    def __repr__(self) -> str:
        return (
            f"Album(titulo={self._titulo!r}, artista={self._artista!r}, "
            f"genero={self._genero!r}, anio={self._anio})"
        )
