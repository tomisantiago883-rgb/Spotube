"""
Modulo: ColeccionAlbumes
TDA contenedor que administra una lista de objetos Album (multiplicidad 1 a *
segun el diagrama UML del TP0). No sabe nada de como se guardan los datos:
solo se ocupa de la logica de negocio sobre la coleccion en memoria.
"""

from typing import List, Optional

from modelo.album import Album


class ColeccionAlbumes:
    def __init__(self):
        self._albumes: List[Album] = []

    # ---------- Carga inicial (viene de un repositorio externo) ----------
    def cargar_desde_lista(self, albumes: List[Album]) -> None:
        self._albumes = list(albumes)

    # ---------- Operacion 1: Registrar ----------
    def registrar_album(self, album: Album) -> None:
        self._albumes.append(album)

    # ---------- Operacion 2: Listar ----------
    def obtener_todos(self) -> List[Album]:
        return list(self._albumes)

    # ---------- Operacion 3: Buscar ----------
    def buscar_por_artista(self, artista: str) -> List[Album]:
        artista = artista.strip().lower()
        return [a for a in self._albumes if artista in a.artista.lower()]

    def buscar_por_titulo(self, titulo: str) -> Optional[Album]:
        titulo = titulo.strip().lower()
        for a in self._albumes:
            if a.titulo.lower() == titulo:
                return a
        return None

    # ---------- Operacion 4: Filtrar ----------
    def filtrar_por_genero(self, genero: str) -> List[Album]:
        genero = genero.strip().lower()
        return [a for a in self._albumes if genero in a.genero.lower()]

    # ---------- Funcionalidad de dominio: Recomendar ----------
    def recomendar_similares(self, titulo: str) -> List[Album]:
        base = self.buscar_por_titulo(titulo)
        if base is None:
            return []
        return [
            a for a in self._albumes
            if a.genero.lower() == base.genero.lower()
            and a.titulo.lower() != base.titulo.lower()
        ]

    # ---------- Funcionalidad de dominio: Eliminar ----------
    def eliminar_album(self, indice: int) -> bool:
        if 0 <= indice < len(self._albumes):
            del self._albumes[indice]
            return True
        return False

    def __len__(self) -> int:
        return len(self._albumes)
