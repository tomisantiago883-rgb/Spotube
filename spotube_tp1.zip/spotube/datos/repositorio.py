"""
Modulo: Repositorio
Se encarga de cargar y guardar los albumes en un archivo JSON.

Esta clase separa "como se guardan los datos" de "como se gestiona la
coleccion" (ver modelo/coleccion_albumes.py). Si el dia de manana
quisieran guardar en CSV o en una base de datos, alcanza con crear otra
clase parecida (por ejemplo RepositorioCSV) con los mismos dos metodos
(cargar y guardar), sin tener que tocar el resto del programa.
"""

import json
import os
from typing import List

from modelo.album import Album


class RepositorioJSON:
    """Se ocupa de leer y escribir la coleccion de albumes en un archivo .json."""

    def __init__(self, ruta_archivo: str):
        self._ruta_archivo = ruta_archivo

    def cargar(self) -> List[Album]:
        """Lee el archivo JSON y devuelve una lista de objetos Album."""
        if not os.path.exists(self._ruta_archivo):
            return []
        with open(self._ruta_archivo, "r", encoding="utf-8") as f:
            datos = json.load(f)
        return [Album.from_dict(item) for item in datos]

    def guardar(self, albumes: List[Album]) -> None:
        """Recibe una lista de objetos Album y los escribe en el archivo JSON."""
        datos = [album.to_dict() for album in albumes]
        with open(self._ruta_archivo, "w", encoding="utf-8") as f:
            json.dump(datos, f, indent=2, ensure_ascii=False)
