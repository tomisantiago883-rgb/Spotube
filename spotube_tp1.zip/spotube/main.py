"""
Spotube - TP1: Objetos y Clases
Interfaz de terminal para gestionar la coleccion de albumes.

Este archivo solo se ocupa de la interaccion con el usuario (input/output).
Toda la logica real vive en modelo/ y datos/.
"""

from modelo.album import Album
from modelo.coleccion_albumes import ColeccionAlbumes
from datos.repositorio import RepositorioJSON

RUTA_DATOS = "datos/albumes.json"


def mostrar_menu():
    print("=" * 55)
    print("MI BIBLIOTECA - SPOTUBE")
    print("=" * 55)
    print("1. Registrar nuevo album      4. Recomendar albumes similares")
    print("2. Ver coleccion completa     5. Eliminar un album")
    print("3. Buscar por artista         6. Filtrar por genero")
    print("7. Salir")
    print("-" * 55)


def registrar_album(coleccion: ColeccionAlbumes):
    titulo = input("Titulo: ").strip()
    artista = input("Artista: ").strip()
    genero = input("Genero: ").strip()
    while True:
        anio_str = input("Anio: ").strip()
        if anio_str.isdigit():
            anio = int(anio_str)
            break
        print("Por favor ingrese un anio valido (numero).")
    coleccion.registrar_album(Album(titulo, artista, genero, anio))
    print(f"[Sistema]: '{titulo}' registrado con exito.\n")


def ver_coleccion(coleccion: ColeccionAlbumes):
    albumes = coleccion.obtener_todos()
    if not albumes:
        print("[Sistema]: La coleccion esta vacia.\n")
        return
    print(f"[Sistema]: Mostrando {len(albumes)} album(es):")
    for i, album in enumerate(albumes):
        print(f"  {i}. {album}")
    print()


def buscar_por_artista(coleccion: ColeccionAlbumes):
    artista = input("Ingrese el nombre del artista: ").strip()
    resultados = coleccion.buscar_por_artista(artista)
    if not resultados:
        print(f"[Sistema]: No se encontraron albumes de '{artista}'.\n")
        return
    print(f"[Sistema]: Albumes de '{artista}':")
    for album in resultados:
        print(f"  * {album}")
    print()


def recomendar_similares(coleccion: ColeccionAlbumes):
    titulo = input("Ingrese el titulo del album base: ").strip()
    base = coleccion.buscar_por_titulo(titulo)
    if base is None:
        print(f"[Sistema]: No se encontro el album '{titulo}'.\n")
        return
    print(f"[Sistema]: Buscando albumes del genero '{base.genero}'...")
    recomendaciones = coleccion.recomendar_similares(titulo)
    if not recomendaciones:
        print("[Sistema]: No hay recomendaciones disponibles.\n")
        return
    print(f"Recomendaciones similares a '{base.titulo}' ({base.artista}):")
    for r in recomendaciones:
        print(f"  * '{r.titulo}' - {r.artista} ({r.anio})")
    print()


def eliminar_album(coleccion: ColeccionAlbumes):
    ver_coleccion(coleccion)
    if len(coleccion) == 0:
        return
    indice_str = input("Ingrese el numero del album a eliminar: ").strip()
    if not indice_str.isdigit():
        print("[Sistema]: Indice invalido.\n")
        return
    if coleccion.eliminar_album(int(indice_str)):
        print("[Sistema]: Album eliminado con exito.\n")
    else:
        print("[Sistema]: Indice fuera de rango.\n")


def filtrar_por_genero(coleccion: ColeccionAlbumes):
    genero = input("Ingrese el genero a filtrar: ").strip()
    resultados = coleccion.filtrar_por_genero(genero)
    if not resultados:
        print(f"[Sistema]: No hay albumes del genero '{genero}'.\n")
        return
    print(f"[Sistema]: Albumes del genero '{genero}':")
    for album in resultados:
        print(f"  * {album}")
    print()


def main():
    repositorio = RepositorioJSON(RUTA_DATOS)
    coleccion = ColeccionAlbumes()
    coleccion.cargar_desde_lista(repositorio.cargar())

    opciones = {
        "1": registrar_album,
        "2": ver_coleccion,
        "3": buscar_por_artista,
        "4": recomendar_similares,
        "5": eliminar_album,
        "6": filtrar_por_genero,
    }

    while True:
        mostrar_menu()
        opcion = input("Seleccione una opcion: ").strip()
        print()
        if opcion == "7":
            repositorio.guardar(coleccion.obtener_todos())
            print("[Sistema]: Datos guardados. Hasta la proxima!")
            break
        accion = opciones.get(opcion)
        if accion:
            accion(coleccion)
        else:
            print("[Sistema]: Opcion invalida.\n")


if __name__ == "__main__":
    main()
